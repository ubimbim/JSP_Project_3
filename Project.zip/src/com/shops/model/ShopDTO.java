package com.shops.model;

public class ShopDTO {
	private String pnum;
	private String pname;
	private int now_no;
	
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getNow_no() {
		return now_no;
	}
	public void setNow_no(int now_no) {
		this.now_no = now_no;
	}
}
