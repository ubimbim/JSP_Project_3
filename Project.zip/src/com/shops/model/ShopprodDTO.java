package com.shops.model;

public class ShopprodDTO {

	private String shop_id;
	private String pnum;
	private int now_no;
	
	public String getShop_id() {
		return shop_id;
	}
	public void setShop_id(String shop_id) {
		this.shop_id = shop_id;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public int getNow_no() {
		return now_no;
	}
	public void setNow_no(int now_no) {
		this.now_no = now_no;
	}
}
